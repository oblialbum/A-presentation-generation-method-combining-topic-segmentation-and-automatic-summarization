Data_preparation includes mapping for datasets and util files for data related functions.

**urls_cnndm** contains the hashed url mapping for CNN and CNNDM.

**urls_nyt** contains the file name of NYT datasets.